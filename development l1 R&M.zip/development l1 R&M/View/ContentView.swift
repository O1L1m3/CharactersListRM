//  Created by Emilio


import SwiftUI

struct ContentView: View {
    
    var body: some View {
        
        HomeView()
    }
}

#Preview {
    ContentView()
}




//struct ContentView: View {
//    @State private var isAnimating = false
//
//    var body: some View {
//        VStack {
//            HomeView()
//                .padding(.top, 55)
//        }
//        .background(.white)
//        .ignoresSafeArea()
//        .borderLoadingAnimation(isAnimating: $isAnimating)
//        
//        .onAppear {
//            withAnimation(.linear(duration: 2).repeatForever(autoreverses: false)) {
//                isAnimating = true
//            }
//        }
//    }
//}
//
//#Preview {
//    ContentView()
//}
//
//extension View {
//    func borderLoadingAnimation(isAnimating: Binding<Bool>) -> some View {
//        modifier(BorderLoadingAnimation(isAnimating: isAnimating))
//    }
//}
//
//struct BorderLoadingAnimation: ViewModifier, Animatable {
//    @Binding var isAnimating: Bool
//    
//    private let lineWidth: CGFloat = 5
//    @State private var hasTopSafeAreaInset: Bool = false
//
//    var animatableData: Bool {
//        get { isAnimating }
//        set { isAnimating = newValue }
//    }
//
//    func body(content: Content) -> some View {
//        content
//            .overlay(
//                GeometryReader { geometry in
//                    RoundedRectangle(cornerRadius: hasTopSafeAreaInset ? 0 : 59)
//                        .stroke(
//                            AngularGradient(
//                                stops: [
//                                    .init(color: .colortext, location: 0),
//                                    .init(color: .num2, location: 0.1),
//                                    .init(color: .num1, location: 0.4),
//                                    .init(color: .colortext, location: 0.5)
//                                ],
//                                center: .center,
//                                angle: .degrees(isAnimating ? 360 : 0)
//                            ),
//                            lineWidth: lineWidth
//                        )
//                        .frame(width: geometry.size.width - lineWidth, height: geometry.size.height - lineWidth)
//                        .padding(.top, lineWidth / 2)
//                        .padding(.leading, lineWidth / 2)
//                        .onAppear {
//                            let topSafeAreaInset = geometry.safeAreaInsets.top
//                            hasTopSafeAreaInset = topSafeAreaInset > 20
//                        }
//                }
//            )
//            .ignoresSafeArea()
//    }
//}




