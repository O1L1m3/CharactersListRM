//
//  development_l1_R_MApp.swift
//  development l1 R&M
//
//  Created by Emilio on 04/06/25.
//

import SwiftUI

@main
struct development_l1_R_MApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
